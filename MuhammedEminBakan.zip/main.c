#include <stdio.h>

int ogrNo[50];
int vize[50];
int finalNotu[50];
float ort[50];
int ogrSayisi = 0;

void menu();
void ogrenciEkle();
void notGir();
void listele();
void ortalamaHesapla();
void minMaxBul();

int main() {
    int secim;

    do {
        menu();
        scanf("%d", &secim);

        switch(secim) {
            case 1: ogrenciEkle(); break;
            case 2: notGir(); break;
            case 3: listele(); break;
            case 4: ortalamaHesapla(); break;
            case 5: minMaxBul(); break;
            case 0: printf("Programdan cikiliyor...\n"); break;
            default: printf("Hatali secim!\n");
        }
    } while(secim != 0);

    return 0;
}

void menu() {
    printf("\n--- OGRENCI NOT TAKIP SISTEMI ---\n");
    printf("1- Ogrenci Ekle\n");
    printf("2- Not Gir\n");
    printf("3- Ogrenci Listele\n");
    printf("4- Ortalama Hesapla\n");
    printf("5- En Yuksek / En Dusuk Not\n");
    printf("0- Cikis\n");
    printf("Seciminiz: ");
}

void ogrenciEkle() {
    printf("Ogrenci numarasi girin: ");
    scanf("%d", &ogrNo[ogrSayisi]);
    ogrSayisi++;
    printf("Ogrenci eklendi.\n");
}

void notGir() {
    for(int i = 0; i < ogrSayisi; i++) {
        printf("\nOgrenci No: %d\n", ogrNo[i]);
        printf("Vize: ");
        scanf("%d", &vize[i]);
        printf("Final: ");
        scanf("%d", &finalNotu[i]);
    }
}

void listele() {
    for(int i = 0; i < ogrSayisi; i++) {
        printf("\nNo: %d Vize: %d Final: %d Ortalama: %.2f",
               ogrNo[i], vize[i], finalNotu[i], ort[i]);
    }
}

void ortalamaHesapla() {
    for(int i = 0; i < ogrSayisi; i++) {
        ort[i] = vize[i] * 0.4 + finalNotu[i] * 0.6;
        printf("\nOgrenci No: %d Ortalama: %.2f ", ogrNo[i], ort[i]);

        if(ort[i] >= 60)
            printf("GECTI");
        else
            printf("KALDI");
    }
}

void minMaxBul() {
    float min = ort[0], max = ort[0];

    for(int i = 1; i < ogrSayisi; i++) {
        if(ort[i] < min) min = ort[i];
        if(ort[i] > max) max = ort[i];
    }

    printf("\nEn Dusuk Ortalama: %.2f", min);
    printf("\nEn Yuksek Ortalama: %.2f", max);
}
